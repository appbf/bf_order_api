const token_salt_arr = ['AEZAKMI',
    'BAGUVIX',
    'FULLCLIP',
    'CVWKXAM',
    'STATEOFEMERGENCY',
    'BLUESUEDESHOES',
    'YSOHNUL',
    'SPEEDITUP',
    'SLOWITDOWN',
    'CJPHONEHOME',
    'KANGAROO',
    'CIKGCGX',
    'PRIEBJ',
    'BEKKNQV',
    'CRAZYTOWN',
    'MUNASEF',
    'IOJUFZN',
    'JCNRUAD',
    'ONLYHOMIESALLOWED',
    'FOOOXFT',
    'BGLUAWML',
    'AJLOJYQY',
    'BAGOWPG',
    'BEKKNQV',
    'GOODBYECRUELWORLD',
    'NINJATOWN',
    'NIGHTPROWLER',
    'GHOSTTOWN',
    'SPEEDFREAK',
    'MONSTERMASH',
    'CELEBRITYSTATUS',
    'WHERESTHEFUNERAL'
];
const token_letter_arr = ['a', 'e', 'i', 'o', 'u', 'z'];
/**
 * category**
 * a: forever
 * b: 1 year
 * c: 6 months
 * d: 3 months
 * e: 1 month
 * f: 1 week
 * g: 2 year
 * h: 3 year
 * i: 5 year
 * z: forever with update permission
 */
const categories = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'z'];
module.exports = {
    token_salt_arr,
    token_letter_arr,
    categories
}