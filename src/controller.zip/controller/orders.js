const { getUserBalance, updateUserBalance, updateUserLockBalance, updateCancleOrderBalance } = require('../utils/function.wallets');
const { createUniqueID, updateTokenPriceAfterTrade } = require('../utils/functions');
const { executeOrder } = require('../utils/functions.orders');
const { createSocketClient } = require('../utils/functions.socket');
const { validateUserId, validateOrderId, getOrderTypeFromOrderId } = require('../utils/validator');

const BuyStack = require('../models/buy_stack');
const SellStack = require('../models/sell_stack');
const socket = createSocketClient('kujgwvfq-z-ghosttown-z-1fhhup0p6');

exports.sellOrder = async (req, res) => {
    // await executeOrder({}, false);
    const body = req.body;
    // console.log("User id: ", body.user_id);
    if (!body.user_id || !validateUserId(body.user_id)) {
        return res.json({
            status: 400,
            error: true,
            message: "Invalid request"
        })
    }
    const {balance} = await getUserBalance(body.user_id, body.currency_type);
    if (body.volume > balance) {
        return res.json({
            status: 200,
            error: true,
            message: 'Insufficient fund in wallet!'
        })
    }
    const order_id      = createUniqueID('sell_order');
    const user_id       = body.user_id;
    const raw_price     = parseFloat(body.raw_price);
    const currency_type = body.currency_type;
    const compare_currency = body.compare_currency;
    const volume        = body.volume;
    const order_date    = Date.now();
    const execution_time= ''; 
    const total_executed    = 0;
    const last_reansaction = '';
    const order_status  = 0;
    const executed_from = '';
    const order_type = body.type == 'p2p' ? 'p2p' : 'exc';
    const lock = false;

    try {
        const sellstack = await SellStack.create({
            order_id, user_id, raw_price, currency_type, compare_currency, volume, order_date, execution_time, total_executed, last_reansaction, order_status, executed_from, order_type, lock
        })
        // console.log("**Sell** Order created: ", "User id: ", user_id, " Currency type: ", currency_type, " Compare currency: ", compare_currency, " Volume: ", volume, " Raw price: ", raw_price);
        const isDeducted = await updateUserLockBalance(user_id, currency_type, volume);
        if (!isDeducted) {
            await SellStack.deleteOne({ "order_id": order_id });
            return res.json({
                status: 200,
                error: true,
                message: 'Insufficient fund in wallet!'
            })
        }
        if (socket.connected) {
            let obj = {
                currency_type,
                compare_currency,
                raw_price,
                volume
            }
            socket.emit("update_sell_stack", obj);
        }
    } catch (error) {
        console.log("Error: >from: controller> orders > sellOrder > try: ", error.message);
        return res.json({
            status: 400,
            error: true,
            message: "Order couldn't create"
        })
    }

    const order = {
        _id: '',
        order_id,
        user_id,
        currency_type,
        compare_currency,
        execution_time: Date.now(),
        total_executed,
        last_reansaction,
        executed_from,
        order_type,
        order_direction: 'sell',
        volume,
        raw_price,
        order_status
    }
    try {
        // const historyId = await executeOrder(order, false);
        // if (historyId) {
        //     return res.json({
        //         status: 200,
        //         error: false,
        //         message: 'Order Created and Executed Successfully!',
        //         order_id
        //     })
        // } else {
        //     return res.json({
        //         status: 200,
        //         error: false,
        //         message: "Order Created Successfully, but didn't Executed (in queue)!",
        //         order_id
        //     })
        // }
        /**
         * new code
         * */
        // const { TxSE } = require('../utils/TxSE');
        // const { updateGraphData } = require('../utils/functions.chart.js')
        // const engine = new TxSE(order);
        // await engine.executeOrder();
        // let isexecuted = await engine.isExecuted();
        // let d = await engine.toString();
        // if (isexecuted) {
        //     // socket.emit("update_order_history", isexecuted);
        //     if (socket.connected) {
        //         socket.emit("update_order_history", isexecuted);
        //         let ob = {
        //             currency_type: order.currency_type,
        //             compare_currency: order.compare_currency,
        //             raw_price: order.raw_price,
        //             volume: (isexecuted.volume)>0? isexecuted.volume: 0
        //         }
        //         socket.emit("delete_sell_stack", ob);
        //         socket.emit("delete_buy_stack", ob);
        //         await updateGraphData(order.currency_type, order.compare_currency, parseFloat(order.raw_price), (isexecuted.volume)>0? parseFloat(isexecuted.volume): 0);
        //         await updateTokenPriceAfterTrade(order.currency_type, order.compare_currency, parseFloat(order.raw_price));
                
        //     }
        //     return res.json({
        //         status: 200,
        //         error: false,
        //         message: 'Order Created and Executed Successfully!',
        //         order_id,
        //         isexecuted,
        //         d
        //     })
        // } else {
        //     return res.json({
        //         status: 400,
        //         error: true,
        //         message: "Order Created Successfully, but didn't Executed (in queue)"
        //     })
        // }
        return res.json({
            status: 200,
            error: false,
            message: "Order Created Successfully",
            order_id
        })
    } catch (error) {
        console.log("Error: >from: controller> orders > sellOrder > try2 (order execution): ", error.message);
        return res.json({
            status: 400,
            error: true,
            message: "Order Created Successfully, but didn't Executed (in queue)*"
        })
    }
    
    return res.json({
        status: 200,
        error: false,
        message: 'Order Created Successfully!',
        order_id
    })
};


exports.buyOrder = async (req, res) => {
    const body = req.body;
    if (!body.user_id || !validateUserId(body.user_id)) {
        return res.json({
            status: 400,
            error: true,
            message: "Invalid request**"
        })
    }
    const {balance} = await getUserBalance(body.user_id, body.compare_currency); // here we will check for compare currency balance
    if (parseFloat(body.volume) * parseFloat(body.raw_price) > balance ) {
        return res.json({
            status: 200,
            error: true,
            message: 'Insufficient fund in wallet!'
        })
    }
    const order_id = createUniqueID('buy_order');
    const user_id = body.user_id;
    const raw_price = parseFloat(body.raw_price);
    const currency_type = body.currency_type;
    const compare_currency = body.compare_currency;
    const volume = parseFloat(body.volume);
    const order_date = Date.now();
    const execution_time = '';
    const total_executed = 0;
    const last_reansaction = '';
    const order_status = 0;
    const executed_from = '';
    const order_type = body.type == 'p2p' ? 'p2p' : 'exc';
    const lock = false;
    
    try {
        const buystack = await BuyStack.create({
            order_id, user_id, raw_price, currency_type, compare_currency, volume, order_date, execution_time, total_executed, last_reansaction, order_status, executed_from, order_type, lock
        })

        // console.log("++Buy++ Order created: ", "User id: ", user_id, " Currency type: ", currency_type, " Compare currency: ", compare_currency, " Volume: ", volume, " Raw price: ", raw_price);
        const isDeducted = await updateUserLockBalance(user_id, compare_currency, (volume)*(raw_price));
        if (!isDeducted) {
            await BuyStack.deleteOne({ "order_id": order_id });
            return res.json({
                status: 200,
                error: true,
                message: 'Insufficient fund in wallet!'
            })
        }
        if (socket.connected) {
            let obj = {
                currency_type,
                compare_currency,
                raw_price,
                volume
            }
            socket.emit("update_buy_stack", obj);
        }
    } catch (error) {
        console.log("Error: >from: controller> orders > buyOrder > try: ", error.message);
        return res.json({
            status: 400,
            error: true,
            message: "Order couldn't create"
        })
    }
    const order = {
        _id: '',
        order_id,
        user_id,
        currency_type,
        compare_currency,
        execution_time: Date.now(),
        total_executed,
        last_reansaction,
        executed_from,
        order_type,
        order_direction: 'buy',
        volume,
        raw_price,
        order_status
    }
    try {
        // const historyId = await executeOrder(order, false);
        // if (historyId) {
        //     return res.json({
        //         status: 200,
        //         error: false,
        //         message: 'Order Created and Executed Successfully!',
        //         order_id
        //     })
        // } else {
        //     return res.json({
        //         status: 200,
        //         error: false,
        //         message: "Order Created Successfully, but didn't Executed (in queue)!",
        //         order_id
        //     })
        // }
        /**
         * new code
         * */
        // const { TxSE } = require('../utils/TxSE');
        // const { updateGraphData } = require('../utils/functions.chart.js')
        // const engine = new TxSE(order);
        // await engine.executeOrder();
        // let isexecuted = await engine.isExecuted();
        // let d = await engine.toString();
        // if (isexecuted) {
        //     // socket.emit("update_order_history", isexecuted);
        //     if (socket.connected) {
        //         socket.emit("update_order_history", isexecuted);
        //         let ob = {
        //             currency_type: order.currency_type,
        //             compare_currency: order.compare_currency,
        //             raw_price: order.raw_price,
        //             volume: (isexecuted.volume)>0? isexecuted.volume: 0
        //         }
        //         socket.emit("delete_sell_stack", ob);
        //         socket.emit("delete_buy_stack", ob);
        //         await updateGraphData(order.currency_type, order.compare_currency, parseFloat(order.raw_price), (isexecuted.volume)>0? parseFloat(isexecuted.volume): 0);
        //         await updateTokenPriceAfterTrade(order.currency_type, order.compare_currency, parseFloat(order.raw_price));
        //     }
        //     return res.json({
        //         status: 200,
        //         error: false,
        //         message: 'Order Created and Executed Successfully!',
        //         order_id,
        //         isexecuted,
        //         d
        //     })
        // } else {
        //     return res.json({
        //         status: 400,
        //         error: true,
        //         message: "Order Created Successfully, but didn't Executed (in queue)"
        //     })
        // }
        return res.json({
            status: 200,
            error: false,
            message: "Order Created Successfully",
            order_id
        })
    } catch (error) {
        console.log("Error: >from: controller> orders > buyOrder > try2 (order execution): ", error);
        return res.json({
            status: 400,
            error: true,
            message: "Order Created Successfully, but didn't Executed (in queue)*"
        })
    }
    return res.json({
        status: 200,
        error: false,
        message: 'Order Created Successfully!',
        order_id
    })
}
exports.orderHistory = async (req, res) => {
    const TradeHistory = require('../models/trade_history');
    try {
        // console.log("Start: ", Date.now())
        const { user_id } = req.body;
        if (user_id && validateUserId(user_id)) {
            const sell_orders = await SellStack.find({user_id: user_id});
            const buy_orders = await BuyStack.find({ user_id: user_id });
            const compleated_orders = [];
            const pending_orders = [];
            
            // if (sell_orders && Array.isArray(sell_orders) && buy_orders && Array.isArray(buy_orders)) {
                // code for selling
            const tradeloopobj = (sell_orders ? sell_orders.length : 0) > (buy_orders?buy_orders.length:0) ? sell_orders : buy_orders;
                var _orders = tradeloopobj.map(async (order, index) => {
                    let new_arr = [];
                    let buy_obj = buy_orders.length > index ? buy_orders[index] : undefined;
                    let sell_obj = sell_orders.length > index ? sell_orders[index] : undefined;
                    // console.log(sell_obj)
                    if (buy_obj && buy_obj.order_status != 2) {
                        let ordr = {};
                        ordr.currency_type = buy_obj.currency_type;
                        ordr.compare_currency = buy_obj.compare_currency;
                        ordr.raw_price = buy_obj.raw_price;
                        ordr.volume = buy_obj.volume;
                        ordr.total_executed = buy_obj.total_executed;
                        ordr.timestamp = buy_obj.order_date;
                        ordr.order_id = buy_obj.order_id;
                        ordr.type = 'buy';
                        if (buy_obj.volume > buy_obj.total_executed) {
                            ordr.status = "p";
                        } else if (buy_obj.volume == buy_obj.total_executed) {
                            ordr.status = "c";
                        }
                        //  = [];
                        const trade_h = await TradeHistory.find({ buy_order_id: buy_obj.order_id });
                        // if (trade_h && Array.isArray(trade_h) && trade_h > 0) {
                            ordr.trades = trade_h.map((h) => {
                                let hobj = {};
                                hobj.trade_date = h.trade_date;
                                hobj.price = h.price;
                                hobj.volume = h.volume;
                                let cf = h.commition_fee ? h.commition_fee.split('+'):undefined;
                                let mf = cf ? cf[0] : 0;
                                hobj.transaction_fee = mf;
                                return hobj;
                                // ordr.trades.push(hobj);
                            })
                        // }
                        new_arr[0] = ordr;
                    }
                    if (sell_obj && sell_obj.order_status != 2) {
                        let ordr = {};
                        ordr.currency_type = sell_obj.currency_type;
                        ordr.compare_currency = sell_obj.compare_currency;
                        ordr.raw_price = sell_obj.raw_price;
                        ordr.volume = sell_obj.volume;
                        ordr.total_executed = sell_obj.total_executed;
                        ordr.timestamp = sell_obj.order_date;
                        ordr.order_id = sell_obj.order_id;
                        ordr.type = 'sell';
                        if (sell_obj.volume > sell_obj.total_executed) {
                            ordr.status = "p";
                        } else if (sell_obj.volume == sell_obj.total_executed) {
                            ordr.status = "c";
                        }
                        const trade_h = await TradeHistory.find({ sell_order_id: sell_obj.order_id });
                        //  = [];
                        // if (trade_h && Array.isArray(trade_h) && trade_h > 0) {
                            ordr.trades = trade_h.map((h) => {
                                let hobj = {};
                                hobj.trade_date = h.trade_date;
                                hobj.price = h.price;
                                hobj.volume = h.volume;
                                let cf = h.commition_fee ? h.commition_fee.split('+'):undefined;
                                let mf = cf ? cf[1] : 0;
                                hobj.transaction_fee = mf;
                                return hobj;
                                // ordr.trades.push(hobj);
                            })
                        // }
                        new_arr[1] = ordr;
                        // console.log(new_arr)
                    }
                    return new_arr;
                });
                // console.log(_orders);
                Promise.all(_orders).then(function (results) {
                    const trade_hist = {};
                    trade_hist.compleated = [];
                    trade_hist.pending = [];
                    results.map((d) => {
                        if (d[0] && d[0].status == 'c') {
                            trade_hist.compleated.push(d[0])
                        } else if (d[0] && d[0].status == 'p') {
                            trade_hist.pending.push(d[0])
                        }
                        if (d[1] && d[1].status == 'c') {
                            trade_hist.compleated.push(d[1])
                        } else if (d[1] && d[1].status == 'p') {
                            trade_hist.pending.push(d[1])
                        }
                    })
                    // console.log("End: ", Date.now())
                    return res.json({
                        status: 200,
                        error: false,
                        params: {
                            trade_history: trade_hist
                        },
                        message: "Success"
                    })
                    /** */
                }).catch((error)=>{
                    console.log("error: ", error.message);
                })
            // } else {
            //     return res.json({
            //         status: 400,
            //         error: true,
            //         message: 
            //     })
            // }
        } else {
            // console.log("End-: ", Date.now())
            return res.json({
                status: 400,
                error: true,
                message: "Invalid request"
            })
        }
    } catch (error) {
        // console.log("End--: ", Date.now())
        console.log("Error: ", error.message)
        return res.json({
            status: 400,
            error: true,
            message: "Something went wrong, please try again"
        })
    }
}
/*
exports.cancleOrder = async (req, res) => {
    try {
        const { user_id, order_id } = req.body;
        if (user_id && validateUserId(user_id)) {
            if (order_id) {
                const order_type = getOrderTypeFromOrderId(order_id);
                if (order_type) {
                    if (order_type == 'sell') {
                        const order_d = await SellStack.findOne({ order_id: order_id, user_id: user_id });
                        if (order_d) {
                            await SellStack.updateOne({ order_id: order_id, user_id: user_id }, {
                                $set: {
                                    order_status: 2
                                }
                            });
                            let final_amount = parseFloat(order_d.volume);
                            await updateCancleOrderBalance(user_id, order_d.currency_type, final_amount);
                            return res.json({
                                status: 200,
                                error: false,
                                message: "Order Cancled Successfully"
                            })
                        } else {
                            return res.json({
                                status: 400,
                                error: true,
                                message: "Invalid attempt"
                            })
                        }
                    } else if (order_type == 'buy') {
                        const order_d = await BuyStack.findOne({ order_id: order_id, user_id: user_id });
                        if (order_d) {
                            await BuyStack.updateOne({ order_id: order_id, user_id: user_id }, {
                                $set: {
                                    order_status: 2
                                }
                            });
                            let final_amount = parseFloat(order_d.raw_price) * parseFloat(order_d.volume);
                            await updateCancleOrderBalance(user_id, order_d.compare_currency, final_amount)
                            return res.json({
                                status: 200,
                                error: false,
                                message: "Order Cancled Successfully"
                            })
                        } else {
                            return res.json({
                                status: 400,
                                error: true,
                                message: "Invalid attempt****"
                            })
                        }
                    }
                } else {
                    return res.json({
                        status: 400,
                        error: true,
                        message: "Invalid attempt***"
                    })
                }
            } else {
                return res.json({
                    status: 400,
                    error: true,
                    message: "Invalid attempt**"
                })
            }
        } else {
            return res.json({
                status: 400,
                error: true,
                message: "Invalid  request*"
            })
        }
    } catch (error) {
        return res.json({
            status: 400,
            error: true,
            message: "Something went wrong, please try again"+error.message
        })
    }
}
*/


exports.cancleOrder = async (req, res) => {
    try {
        const { user_id, order_id } = req.body;
        if (user_id && validateUserId(user_id)) {
            if (order_id) {
                const order_type = getOrderTypeFromOrderId(order_id);
                if (order_type) {
                    if (order_type == 'sell') {
                        const order_d = await SellStack.findOne({ order_id: order_id/*, user_id: user_id */});
                        console.log('order_d',order_d)
                        if (order_d && order_d.lock && order_d.lock != true && order_d.order_status == 0) {
                            const total_volume = order_d.volume ? parseFloat(order_d.volume) : 0;
                            const total_executed = order_d.total_executed ? parseFloat(order_d.total_executed) : 0;
                            const remaining_volume = total_volume - total_executed;
                            if (remaining_volume > 0) {
                                await SellStack.updateOne({ order_id: order_id, user_id: user_id }, {
                                    $set: {
                                        order_status: 2
                                    }
                                });
                                /** 
                                 * volume -
                                 * total_executed
                                 * = cancle locked
                                 */
                                console.log("**Sell** Order cancled: ", "User id: ", user_id, " Currency type: ", order_d.currency_type, " Compare currency: ", order_d.compare_currency, " Volume: ", order_d.volume, " Raw price: ", order_d.raw_price, " Executed: ", order_d.total_executed);
                                await updateUserLockBalance(user_id, order_d.currency_type, (-1)*remaining_volume);
                                return res.json({
                                    status: 200,
                                    error: false,
                                    message: "Order Cancled Successfully"
                                })
                            } else {
                                await SellStack.updateOne({ order_id: order_id, user_id: user_id }, {
                                    $set: {
                                        order_status: 2
                                    }
                                });
                                return res.json({
                                    status: 200,
                                    error: false,
                                    message: "Order Cancled Successfully"
                                })
                            }
                        } else {
                            return res.json({
                                status: 400,
                                error: true,
                                message: "Invalid attempt--"
                            })
                        }
                    } else if (order_type == 'buy') {
                        const order_d = await BuyStack.findOne({ order_id: order_id/*, user_id: user_id*/ });
                        console.log("order_id: order_data: ", order_id, order_d)
                        if (order_d && order_d.lock && order_d.lock != true && order_d.order_status == 0) {
                            const total_volume = order_d.volume ? parseFloat(order_d.volume) : 0;
                            const total_executed = order_d.total_executed ? parseFloat(order_d.total_executed) : 0;
                            const remaining_volume = (total_volume - total_executed) * (order_d.raw_price?parseFloat(order_d.raw_price):0);
                            if (remaining_volume > 0) {
                                await BuyStack.updateOne({ order_id: order_id, user_id: user_id }, {
                                    $set: {
                                        order_status: 2
                                    }
                                });
                                console.log("++Buy++ Order cancled: ", "User id: ", user_id, " Currency type: ", order_d.currency_type, " Compare currency: ", order_d.compare_currency, " Volume: ", order_d.volume, " Raw price: ", order_d.raw_price, " Executed: ", order_d.total_executed);
                                await updateUserLockBalance(user_id, order_d.compare_currency, (-1) * remaining_volume);
                                return res.json({
                                    status: 200,
                                    error: false,
                                    message: "Order Cancled Successfully"
                                })
                            } else {
                                await BuyStack.updateOne({ order_id: order_id, user_id: user_id }, {
                                    $set: {
                                        order_status: 2
                                    }
                                });
                                return res.json({
                                    status: 200,
                                    error: false,
                                    message: "Order Cancled Successfully"
                                })
                            }
                        } else {
                            return res.json({
                                status: 400,
                                error: true,
                                message: "Invalid attempt*"
                            })
                        }
                    }
                } else {
                    return res.json({
                        status: 400,
                        error: true,
                        message: "Invalid attempt@"
                    })
                }
            } else {
                return res.json({
                    status: 400,
                    error: true,
                    message: "Invalid attempt@@"
                })
            }
        } else {
            return res.json({
                status: 400,
                error: true,
                message: "Invalid  request_"
            })
        }
    } catch (error) {
        return res.json({
            status: 400,
            error: true,
            message: "Something went wrong, please try again"
        })
    }
}

exports.openOrder = async (req, res) => {
    try {
        const buyStack = require('../models/buy_stack');
        const sellStack = require('../models/sell_stack');
        const { user_id, status, order_id } = req.query;
        if (status || status === 0  ) {
            const buy = await buyStack.aggregate( [
                { "$match": { order_status: parseInt(status) } }, 
                {
                    $lookup: {
                        from: "pending_kyc",
                        localField: "user_id",
                        foreignField: "user_id",
                        as: "pending_kyc",
                    }
                },
            ] );
            const sell = await sellStack.aggregate( [
                { "$match": { order_status: parseInt(status) } }, 
                {
                    $lookup: {
                        from: "pending_kyc",
                        localField: "user_id",
                        foreignField: "user_id",
                        as: "pending_kyc",
                    }
                },
            ] );
            return res.json({
                status: 200,
                buy_stack: buy,
                sell_stack: sell,
                error: false,
                message: "success"
            })
        } else {
            return res.json({
                status: 400,
                error: true,
                message: "Invalid  request"
            })
        }
    } catch (error) {
        return res.json({
            status: 400,
            error: true,
            message: "Something went wrong, please try again"
        })
    }
}
exports.allHistory = async (req, res) => {
    try {
        const TradeHistory = require('../models/trade_history');
        const { user_id, status, order_id } = req.query;
        if (status ) {
            const data = await TradeHistory.find({});
            return res.json({
                status: 200,
                data: data,
                error: false,
                message: "success"
            })
        } else {
            return res.json({
                status: 400,
                error: true,
                message: "Invalid  request"
            })
        }
    } catch (error) {
        return res.json({
            status: 400,
            error: true,
            message: "Something went wrong, please try again"
        })
    }
}