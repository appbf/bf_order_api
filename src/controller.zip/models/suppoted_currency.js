const mongoose = require("mongoose");

const suppoted_currencySchema = new mongoose.Schema(
  {
    coin_id: { type: Number,default: 0 },
    symbol: { type: String, required:true, unique: true, trim: true },
    name: { type: String, required:true, unique: true, trim: true },
    icon: { type: String, trim: true },                  
    dw: { type: Number },
    pairing_currency: { type: String },
    is_paired_inr: { type: Number, default: 0 },
    is_paired_usdt: { type: Number, default: 0 },
    is_paired_btc: { type: Number, default: 0 },
    is_paired_vrx: { type: Number, default: 0 },
    inr_price: { type: Number, default: 0 },
    usdt_price: { type: Number, default: 0 },
    btc_price: { type: Number, default: 0 },
    vrx_price: { type: Number, default: 0 },
    is_paired: { type: Boolean, default: false },
    is_buy: { type: Boolean, default: false },
    is_sell: { type: Boolean, default: false },
    is_trade: { type: Boolean, default: 0 },
    is_withdrawal: { type: Boolean, default: 0 },
    is_deposite: { type: Boolean, default: 0 },
    coin_status: { type: Boolean, default: true },
    contract_address: { type: String, default: '' },
    contract_type: { type: String, default: '' },
    trade_fee: { type: Number, default: 0},
    withdrawal_fee: { type: Number, default: 0 },
    deposit_fee: { type: Number, default: 0 },
    buy_limit: { type: Number, default: 0 },
    sell_limit: { type: Number, default: 0 },
    withdrawal_limit: { type: Number, default: 0 },
    precision: { type: String, trim: true },
    supply: { type: String },
    blockchain: { type: String },
    token_type: { type: String },
    sync_wallet: { type: Boolean, default:false },
  },
  { timestamps: true, collection: "suppoted_currency" }
);

module.exports = mongoose.model("suppoted_currency", suppoted_currencySchema);
